export const ADS_FETCH = 'ADS_FETCH'
export const AD_SAVE_INFO = 'AD_SAVE_INFO'