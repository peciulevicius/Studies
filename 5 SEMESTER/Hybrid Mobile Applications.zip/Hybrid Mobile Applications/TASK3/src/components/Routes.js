// import HomeScreen from "../screens/Home.screen";
// import AddPostScreen from "../screens/AddPost.screen";
// import ProfileScreen from "../screens/Profile.screen";
// import EditScreen from "../screens/Edit.screen";

// import { createStackNavigator } from "@react-navigation/stack";
// import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
// import { NavigationContainer } from "@react-navigation/native";

// const NavStack = createStackNavigator(
//   {
//     Edit: {
//       screen: EditScreen,
//     //   navigationOptions: () => ({
//     //     headerTitle: "Edit",
//     //   }),
//     },
//   },

// );

// const BottomTab = createBottomTabNavigator({
//   Home: {
//     screen: HomeScreen,
//     // navigationOptions: () => ({
//     //   headerTitle: "Home",
//     // }),
//   },
//   NavStack: {
//     screen: NavStack,
//   },
//   AddPost: {
//     screen: AddPostScreen,
//   },
//   Profile: {
//     screen: ProfileScreen,
//   },
// });

// export default Routes = createAppContainer(BottomTab);
