import React from "react";

import { NavigationContainer } from "@react-navigation/native";
import { createDrawerNavigator } from "@react-navigation/drawer";

import HomeScreen from "./src/screens/HomeScreen.component";
import SecondaryScreen from "./src/screens/SecondaryScreen.component";

const Drawer = createDrawerNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Home" headerMode="none">
        <Drawer.Screen name="Home" component={HomeScreen} />
        <Drawer.Screen name="SecondaryScreen" component={SecondaryScreen} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}
