import React from "react";
import { StyleSheet, View, Text } from "react-native";

const SecondaryScreen = ({color}) => {
  return (
    <View style={[backgroundColor: {color}]}>
      <Text>Color is {color}</Text>
    </View>
  );
};

export default SecondaryScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fff",
  },
});
