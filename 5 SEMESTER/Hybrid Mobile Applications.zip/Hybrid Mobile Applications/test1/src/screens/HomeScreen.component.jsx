import React, { useState } from "react";
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  TouchableOpacity,
} from "react-native";
import SecondaryScreen from "../screens/SecondaryScreen.component.jsx";

const HomeScreen = () => {
  const [color, setColor] = useState("transparent");

  const addColor = () => {
    setColor({color})
  };

  return (
    <View style={styles.container}>
      <TextInput onPress={color} style={styles.inputField} placeholder="enter color here"></TextInput>
      <TouchableOpacity
        style={styles.addColorButton}
        OnNavigate={() => navigation.navigate("SecondaryScreen")}
      >
        <Text>open new screen</Text>
      </TouchableOpacity>
    </View>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fff",
  },
  inputField: {
    backgroundColor: "#fff",
    borderColor: "blue",
    borderRadius: 10,
    borderWidth: 1,
    padding: 10,
    marginBottom: 10,
    width: "80%",
    borderRadius: 10,
    alignSelf: "center",
  },
  addColorButton: {
    margin: 15,
    height: 50,
    backgroundColor: "#667EEA",
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    width: "80%",
    alignSelf: "center",
  },
});
